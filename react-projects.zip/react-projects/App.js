import React from "react";
import UserCard2 from "./UserCard2";
import "./App.css";

const users = [
  { name: "John Doe", avatar: "https://randomuser.me/api/portraits/men/1.jpg", email: "johndoe@gmail.com", phone: "123-465-7890" },
  { name: "Jane Doe", avatar: "https://randomuser.me/api/portraits/women/2.jpg", email: "janedoe@gmail.com", phone: "098-765-4321" },
  { name: "Jack Smith", avatar: "https://randomuser.me/api/portraits/men/3.jpg", email: "jacksmith@gmail.com", phone: "345-678-9012" },
  { name: "Jill Smith", avatar: "https://randomuser.me/api/portraits/women/4.jpg", email: "jillsmith@gmail.com", phone: "901-234-5678" },
  { name: "Tom Jones", avatar: "https://randomuser.me/api/portraits/men/5.jpg", email: "tomjones@gmail.com", phone: "012-345-6789" },
  { name: "Kim Jones", avatar: "https://randomuser.me/api/portraits/women/5.jpg", email: "kimjones@gmail.com", phone: "980-123-4567" }
];

const App = () => {
  return (
    <div className="card-container">
      {users.map((user, index) => (
        <UserCard2 key={index} {...user} />
      ))}
    </div>
  );
};

export default App;
