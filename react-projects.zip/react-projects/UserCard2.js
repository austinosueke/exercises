import React, { useState } from "react";
import "./UserCard2.css";

const UserCard2 = ({ name, avatar, email, phone }) => {
  const [showInfo, setShowInfo] = useState(true);

  return (
    <div className="user-card">
      <img src={avatar} alt={name} />
      <div>
        <h3>{name}</h3>
        {showInfo && (
          <div className="info">
            <p>{email}</p>
            <p>{phone}</p>
          </div>
        )}
        <button onClick={() => setShowInfo(!showInfo)}>
          {showInfo ? "Hide Info" : "Show Info"}
        </button>
      </div>
    </div>
  );
};

export default UserCard2;
