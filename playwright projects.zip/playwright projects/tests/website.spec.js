// @ts-check
import { test, expect } from '@playwright/test';

test('Has correct title', async ({ page }) => {
  await page.goto('http://www.austinosueke.com');

  // Verify the page title is "Austin Osueke | Web Producer & UX Designer | San Jose, California"
  await expect(page).toHaveTitle('Austin Osueke | Web Producer & UX Designer | San Jose, California');
});

test('Navigation links are visible and clickable', async ({ page }) => {
  await page.goto('http://www.austinosueke.com');

  // If menu is hidden, click the menu button
  const menu = page.locator('.main-menu');
  if (await menu.isHidden()) {
    await page.locator('.nav-switch-btn').click();
  }

  // Ensure menu is visible before checking links
  await page.waitForSelector('.main-menu', { state: 'visible' });

  const navLinks = ['Home', 'About', 'Portfolio', 'LinkedIn', 'Contact'];

  for (const link of navLinks) {
    const navElement = page.getByRole('link', { name: link });
    await expect(navElement).toBeVisible();
    await navElement.click();
    await page.waitForLoadState('domcontentloaded');
  }
  
  console.log('All Navigation links are checked!');  
  
});


test('Index page contains specific texts', async ({ page }) => {
  await page.goto('http://www.austinosueke.com');

  // Verify the presence of expected text
  await expect(page.locator('body')).toContainText("Hello, I'm Austin Osueke");
  await expect(page.locator('body')).toContainText(
    'I am a skilled Web Producer and UX Designer with extensive experience in front-end design, UI/UX, web technologies, and project management, having worked with top companies like Apple and Cisco.'
  );
});

test('Download Resume button is visible and clickable', async ({ page }) => {
  await page.goto('http://www.austinosueke.com');

  // Verify the presence of the "Download Resume" button
  const downloadButton = page.getByRole('button', { name: 'Download Resume' });
  await expect(downloadButton).toBeVisible();
});




test('Check for broken links on the index page', async ({ page }) => {
  const baseURL = 'http://www.austinosueke.com';
  await page.goto(baseURL);

  console.log('🔍 Checking links on index page...');

  // Get all links on the page
  const links = await page.$$eval('a[href]', anchors =>
    anchors.map(a => a.href)
  );

  console.log(`🔗 Found ${links.length} links to check.`);

  // Check each link for broken responses
  for (const link of links) {
    console.log(`➡️ Checking: ${link}`);

    try {
      const response = await page.request.get(link);
      const status = response.status();

      if (status >= 400) {
        console.error(`❌ Broken link: ${link} (Status: ${status})`);
      } else {
        console.log(`✅ Working link: ${link} (Status: ${status})`);
      }

      // Ensure no broken links (fail the test if any link is broken)
      expect(status).toBeLessThan(400);
    } catch (error) {
      console.error(`❌ Error checking link: ${link}`);
    }
  }

  console.log('✅ Link check completed!');
});
