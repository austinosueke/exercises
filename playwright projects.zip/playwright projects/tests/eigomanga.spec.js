// @ts-check
import { test, expect } from '@playwright/test';

test('has title', async ({ page }) => {
  await page.goto('https://www.eigomanga.com/#start.html');
  await expect(page).toHaveTitle(/eigoMANGA/);
});

test('has News in nav menu', async ({ page }) => {
  await page.goto('https://www.eigomanga.com/#start.html');
  await expect(page.getByRole('link', { name: 'News' })).toBeVisible();
});
