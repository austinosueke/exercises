// @ts-check
import { test, expect } from '@playwright/test';

test('Verify user cards and names', async ({ page }) => {
  // Go to local file
  await page.goto('http://localhost:3000/');

  // Select all user cards
  const userCards = page.locator('.user-card'); // Assuming user cards have the class "user-card"

  // Check if there are exactly 6 user cards
  await expect(userCards).toHaveCount(6);

  // Expected names in order
  const expectedNames = [
    'John Doe',
    'Jane Doe',
    'Jack Smith',
    'Jill Smith',
    'Tom Jones',
    'Kim Jones'
  ];

  // Loop through each user card and verify its text
  for (let i = 0; i < expectedNames.length; i++) {
    await expect(userCards.nth(i)).toContainText(expectedNames[i]);
  }
});


test('Verify all buttons work', async ({ page }) => {
  // Go to local file
  await page.goto('http://localhost:3000/');

  // Select all buttons on the page
  const buttons = page.locator('button');

  // Ensure there is at least one button to test
  const buttonCount = await buttons.count();
  expect(buttonCount).toBeGreaterThan(0);

  // Loop through each button, click it, and check for errors
  for (let i = 0; i < buttonCount; i++) {
    const button = buttons.nth(i);
    await expect(button).toBeVisible(); // Ensure button is visible
    await button.click(); // Click the button
    await page.waitForTimeout(500); // Small delay to allow actions to process
  }

  console.log(`All ${buttonCount} buttons were clicked successfully.`);
});

